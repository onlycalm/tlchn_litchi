XCODE_SCHEME_DEBUG_AS_ROOT
--------------------------

.. versionadded:: 3.15

Whether to debug the target as 'root'.

Please refer to the :prop_tgt:`XCODE_GENERATE_SCHEME` target property
documentation to see all Xcode schema related properties.
