PRECOMPILE_HEADERS_REUSE_FROM
-----------------------------

.. versionadded:: 3.16

Target from which to reuse the precompiled headers build artifact.

See the second signature of :command:`target_precompile_headers` command
for more detailed information.
