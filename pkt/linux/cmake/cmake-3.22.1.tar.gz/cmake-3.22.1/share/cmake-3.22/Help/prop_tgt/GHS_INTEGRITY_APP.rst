GHS_INTEGRITY_APP
-----------------

.. versionadded:: 3.14

``ON`` / ``OFF`` boolean to determine if an executable target should
be treated as an `Integrity Application`.

If no value is set and if a ``.int`` file is added as a source file to the
executable target it will be treated as an `Integrity Application`.

Supported on :generator:`Green Hills MULTI`.
