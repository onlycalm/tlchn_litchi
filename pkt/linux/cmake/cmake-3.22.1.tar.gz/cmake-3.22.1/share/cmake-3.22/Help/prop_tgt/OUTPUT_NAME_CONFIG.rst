OUTPUT_NAME_<CONFIG>
--------------------

Per-configuration target file base name.

This is the configuration-specific version of the :prop_tgt:`OUTPUT_NAME`
target property.
