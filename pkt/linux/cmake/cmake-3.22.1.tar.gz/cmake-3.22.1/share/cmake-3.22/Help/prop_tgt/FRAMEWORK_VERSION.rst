FRAMEWORK_VERSION
-----------------

.. versionadded:: 3.4

Version of a framework created using the :prop_tgt:`FRAMEWORK` target
property (e.g. ``A``).

This property only affects macOS, as iOS doesn't have versioned
directory structure.
