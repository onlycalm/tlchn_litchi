CMAKE_OSX_ARCHITECTURES
-----------------------

.. include:: ENV_VAR.txt

Target specific architectures for macOS.

The ``CMAKE_OSX_ARCHITECTURES`` environment variable sets the default value for
the :variable:`CMAKE_OSX_ARCHITECTURES` variable. See
:prop_tgt:`OSX_ARCHITECTURES` for more information.
